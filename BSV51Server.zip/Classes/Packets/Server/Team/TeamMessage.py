from Classes.Packets.PiranhaMessage import PiranhaMessage


class TeamMessage(PiranhaMessage):
    def __init__(self, messageData):
        super().__init__(messageData)
        self.messageVersion = 0

    def encode(self, fields, player):
        #sub_C56F88 start (TEAM ENTRY)
        self.writeVInt(0) #room type
        self.writeBoolean(False)
        self.writeVInt(0)
        #Xz ID start
        self.writeInt(0)
        self.writeInt(8232399)
        #Xz ID end
        self.writeVInt(0)
        self.writeBoolean(False)
        self.writeBoolean(False)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeDataReference(15, 9)#sub_87762C
        self.writeBoolean(False)
#sub_2BFF10

        self.writeVInt(1)
#sub_5C5674 start (Team Member Entry)

        self.writeBoolean(True)
        #Player ID Start
        self.writeInt(0)
        self.writeInt(player.ID[1])
        #Player ID end
        self.writeDataReference(16, 0)#sub_87762C
        self.writeDataReference(29, 0) #skin
        self.writeVInt(0)
        self.writeVInt(0) #trph
        self.writeVInt(0) #high trph
        self.writeVInt(11) #power lvl
        self.writeVInt(3) #state
        self.writeVInt(0) #is ready
        self.writeVInt(0) #team
        self.writeVInt(0)

        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeString("лошара")
        
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
#sub_1A2060 end
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)

        self.writeVInt(0)
        

        self.writeVInt(0)
        

        self.writeVInt(0) #Array

        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        

#sub_A72240 start
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
#sub_A72250 end
        self.writeVInt(0)
        
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)


    def decode(self):
        return {}

    def execute(message, calling_instance, fields):
        pass

    def getMessageType(self):
        return 24124

    def getMessageVersion(self):
        return self.messageVersion