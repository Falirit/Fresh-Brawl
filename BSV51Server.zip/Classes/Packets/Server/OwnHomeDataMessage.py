import json
from Classes.Utility import Utility
import random
from Classes.Packets.PiranhaMessage import PiranhaMessage
from Database.DatabaseHandler import DatabaseHandler
from Classes.ByteStreamHelper import ByteStreamHelper
from Classes.Packets.PiranhaMessage import PiranhaMessage
from Static.StaticData import StaticData
from Classes.Logic.LogicStarrDropData import starrDropOpening
from datetime import datetime
from datetime import timedelta

import time
import brawlstats
import Configuration
import random

#680 - горячая зона
#666 - карта мегакопилки

import time
""" 
a = int(input("Напиши время, сколько должна действовать акция/техперерыв: -> "))
b = input("1: минуты, 2: часы, 3: дни, 4: месяцы: -> ")

if a == 0:
    print("Вы ввели неверное время")
else:
    seconds = 0
    if b == "1":
        seconds = a * 60
    elif b == "2":
        seconds = a * 60 * 60
    elif b == "3":
        seconds = a * 60 * 60 * 24
    elif b == "4":
        seconds = a * 60 * 60 * 24 * 30
    if seconds != 0:
        end_time = time.time() + seconds
        print("Твое время: \n", end_time)
        print("В секундах: \n", seconds)
    else:
        print("Вы ввели неверный режим")
"""
import threading

def run_every_n_seconds(seconds, action, *args, self, fields, player):
    threading.Timer(seconds, run_every_n_seconds, [seconds, action] + list(args)).start()
    action(*args)
    






fivevsfivemap = 642
fivevsfivemap2 = 643
HyperPowerMap = random.randint(8, 14)

class OwnHomeDataMessage(PiranhaMessage):
    def __init__(self, messageData):
        super().__init__(messageData)
        self.messageVersion = 0
        
    def Timer(self):
    	result = time.localtime(int(time.time()))
    	return (86400 - (result.tm_sec + (result.tm_min * 60) + (result.tm_hour * 3600)))

    def encode(self, fields, player):
        endsBrawlPassSeason = datetime.strptime("03.05.2024 18:00", "%d.%m.%Y %H:%M").timestamp()
        endsBrawlPassSeason2 = endsBrawlPassSeason - datetime.now().timestamp()
        print(endsBrawlPassSeason2)
              
        ownedBrawlersCount = len(player.OwnedBrawlers)
        ownedPinsCount = len(player.OwnedPins)
        ownedTitlesCount = len(player.OwnedTitles)
        ownedThumbnailCount = len(player.OwnedThumbnails)
        ownedSkins = []
        
        
        
        
        self.writeVInt(int(time.time()))
        self.writeVInt(0)

        self.writeVInt(0)
        self.writeVInt(0)

        self.writeVInt(player.Trophies) # Trophies
        self.writeVInt(player.HighestTrophies) # Highest Trophies
        self.writeVInt(player.HighestTrophies)
        self.writeVInt(player.TrophyRoadTier)
        self.writeVInt(1488) # Experience
        self.writeDataReference(28, player.Thumbnail) # Thumbnail
        self.writeDataReference(43, player.Namecolor) # Namecolor

        self.writeVInt(40) # PlayedGameModesArray
        for x in range(40):
            self.writeVInt(x)

        try:
        	player.BrawlersSelectedSkins
        except KeyError:
        	player.BrawlersSelectedSkins = {}
        self.writeVInt(len(player.BrawlersSelectedSkins)) # Selected Skins
        for brawlerID in player.BrawlersSelectedSkins:
        	skinID = player.BrawlersSelectedSkins[brawlerID]
        	self.writeDataReference(29, skinID)

        self.writeVInt(0) # Randomizer Skin Selected

        self.writeVInt(0) # Current Random Skin
        
        self.writeVInt(1488)
        for x in range(1488):
            self.writeDataReference(29, x) # unlocked skin array


        self.writeVInt(0) # Unlocked Skin Purchase Option

        self.writeVInt(0) # New Item Stat
        
        
        self.writeVInt(0) # Leaderboard Region
        self.writeVInt(player.HighestTrophies)
        self.writeVInt(0) # Tokens Used in Battles
        self.writeVInt(1) # Control Mode
        self.writeBoolean(True) # Battle Hints?
        self.writeVInt(player.TokensDoubler)
        self.writeVInt(115)
        self.writeVInt(999999) # Trophy Road Timer
        self.writeVInt(int(endsBrawlPassSeason2)) # Power Play Timer(Don't work')
        self.writeVInt(Utility.timerGetTime(self, "timerbp1")) # Brawl Pass Timer

        self.writeVInt(player.Tokens)
        self.writeVInt(200)
        self.writeVInt(0)

        self.writeBoolean(True) # Token Doubler Enabled
        self.writeVInt(2)  # Token Doubler New Tag State
        self.writeVInt(2)  # Event Tickets New Tag State
        self.writeVInt(2)  # Coin Packs New Tag State
        self.writeVInt(player.CostName)  # Change Name Cost
        self.writeVInt(player.TimeForNextNameChange)  # Timer For the Next Name Change
        
        '''
        0: FREE BOX
        1: COINS
        2: RANDOM BRAWLER RARITY
        3: BRAWLER
        4: SKIN
        5: ITEM
        6: BRAWL BOX
        7: TICKETS
        8: POWER POINTS
        9: TOKEN DOUBLER
        10: MEGA BOX
        11: KEYS
        12: POWER POINTS
        13: NEW EVENT SLOT
        14: BIG BOX
        15: BRAWL BOX
        16: GEMS
        17: STAR POINTS
        18: QUEST???
        19: PIN
        20: SET OF PINS
        21: PIN PACK
        22: PIN PACK FOR
        23: PIN OF RARITY
        24: SKIN AND HERO
        25: PLAYER THUMBNAIL
        26: PURCHASE OPTION SKIN
        27: PIN PACK OF RARITY
        28: BRAWL PASS TOKENS
        29: CLUB FEATURE
        30: NEW BRAWLER UPGRADED TO LEVEL
        31: RANDOM BRAWLER OF RARITY UPGRADED TO LEVEL
        32: GEAR TOKENS
        33: SCRAP
        35: SPRAY
        36: SPRAY BUNDLE
        37: SPRAY SLOT
        38: RECRUIT TOKEN
        39: CHROMATIC TOKEN
        41: POWER POINTS
        42: BRAWL PASS TAIL REWARD
        43: PLAYER TITLE
        44: DAILY QUESTS
        '''

        ShopData = StaticData.ShopData

        self.writeVInt(2 + len(ShopData["Offers"])) # Offers count
        
        self.writeVInt(2) # RewardCount

        self.writeVInt(3)  # ItemType
        self.writeVInt(1) # Amount
        self.writeDataReference(16, 77)  # CsvID
        self.writeVInt(1) # SkinID
        
        self.writeVInt(1)  # ItemType
        self.writeVInt(2500) # Amount
        self.writeDataReference(0)  # CsvID
        self.writeVInt(0) # SkinID
        
        
        self.writeVInt(6) # Currency(0-Gems, 1-Gold, 3-StarpoInts)
        self.writeVInt(1488) # Cost
        self.writeVInt(999999) # Time
        self.writeVInt(0)
        self.writeVInt(0)
        if -148888 in player.PushasedOffers:
                self.writeBoolean(False) # Claim
        else:
            self.writeBoolean(False) # Claim
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False) # Daily Offer
        self.writeVInt(179) # Old price
        self.writeString("ДЕНЬ 1") # Text
        self.writeVInt(1)
        
        self.writeBoolean(False) #If True offer open on menu
               
        self.writeString("offer_bgr_xmas23") # Background
        self.writeVInt(0)
        self.writeBoolean(False) # This purchase is already being processed
        self.writeVInt(0) # Type Benefit
        self.writeVInt(0) # Benefit
        self.writeString("ллл")
        self.writeBoolean(False) # One time offer
        self.writeBoolean(False) # Claimed
        self.writeDataReference(69, 9)
        self.writeDataReference(70, 0)
        self.writeBoolean(False)
        self.writeBoolean(False)
        self.writeBoolean(False)
        self.writeVInt(0)
        self.writeVInt(16)
        self.writeVInt(77)
        self.writeBoolean(False)
        self.writeBoolean(False)
        self.writeVInt(2)
        self.writeVInt(0) #доступно через (время)
        self.writeBoolean(False) #подарки 
        self.writeVInt(0) #Day Gift
        self.writeVInt(0) #Mode(0- Default, 1 - Gift)
        self.writeVInt(0) #Purchased(Gift offer)
        self.writeVInt(-1)
        self.writeVInt(0)
        
        self.writeVInt(1) # RewardCount

        self.writeVInt(50)  # ItemType
        self.writeVInt(1) # Amount
        self.writeDataReference(0)  # CsvID
        self.writeVInt(0) # SkinID
        
        
        self.writeVInt(0) # Currency(0-Gems, 1-Gold, 3-StarpoInts)
        self.writeVInt(0) # Cost
        self.writeVInt(99999) # Time
        self.writeVInt(0)
        self.writeVInt(0)
        if -148888 in player.PushasedOffers:
                self.writeBoolean(False) # Claim
        else:
            self.writeBoolean(False) # Claim
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False) # Daily Offer
        self.writeVInt(179) # Old price
        self.writeString("ДЕНЬ 2") # Text
        self.writeVInt(1)
        self.writeVInt(0)
        self.writeString("offer_bgr_xmas23") # Background
        self.writeVInt(0)
        self.writeBoolean(False) # This purchase is already being processed
        self.writeVInt(0) # Type Benefit
        self.writeVInt(0) # Benefit
        self.writeString("ллл")
        self.writeBoolean(False) # One time offer
        self.writeBoolean(False) # Claimed
        self.writeDataReference(69, 9)
        self.writeDataReference(70, 1)
        self.writeBoolean(False)
        self.writeBoolean(False)
        self.writeBoolean(False)
        self.writeVInt(0)
        self.writeVInt(16)
        self.writeVInt(77)
        self.writeBoolean(False)
        self.writeBoolean(False)
        self.writeVInt(2)
        self.writeVInt(99999) #доступно через (время)
        self.writeBoolean(False) #подарки 
        self.writeVInt(0) #Day Gift
        self.writeVInt(0) #Mode(0- Default, 1 - Gift)
        self.writeVInt(0) #Purchased(Gift offer)
        self.writeVInt(1)
        self.writeVInt(1)
        
        
        
        for i in ShopData["Offers"]:
            def checkAvailability():
            	results = []
            	result = False
            	for reward in i["Rewards"]:
            		if reward["ItemType"] == 4:
            			if reward["Extra"] in ownedSkins:
            				if len(i["Rewards"]) > 1:
            					results.append(True)
            				else:
            					result = True
            			if str(reward["BrawlerID"][1]) not in list(player.OwnedBrawlers.keys()):
            				midresult = False
            				for x in i["Rewards"]:
            					if x["ItemType"] == 3:
            						midresult = True
            				if midresult != True:
            					if len(i["Rewards"]) > 1:
            						results.append(True)
            					else:
            						result = True
            		if reward["ItemType"] == 3 or reward["ItemType"] == 30:
            			if str(reward["BrawlerID"][1]) in list(player.OwnedBrawlers.keys()):
            				if len(i["Rewards"]) > 1:
            					results.append(True)
            				else:
            					result = True
            		if reward["ItemType"] == 19:
            			if reward["Extra"] in player.OwnedPins:
            				if len(i["Rewards"]) > 1:
            					results.append(True)
            				else:
            					result = True
            		if reward["ItemType"] == 25:
            			if reward["Extra"] in player.OwnedThumbnails:
            				if len(i["Rewards"]) > 1:
            					results.append(True)
            				else:
            					result = True
            	if i["Rewards"].index(reward) == len(i["Rewards"]) -1:
            		if True in results:
            			result = True
            	return result
            self.writeVInt(len(i["Rewards"]))  # RewardCount
            for reward in i["Rewards"]:
                self.writeVInt(reward["ItemType"]) # ItemType
                self.writeVInt(reward["Amount"])
                if reward["BrawlerID"][0] != 0:
                    self.writeDataReference(reward["BrawlerID"][0], reward["BrawlerID"][1]) # CsvID
                else:
                    self.writeDataReference(0)
                self.writeVInt(reward["Extra"])

            self.writeVInt(i["Currency"])
            self.writeVInt(i["Cost"])
            self.writeVInt(i["Time"])
            self.writeVInt(0) # State
            self.writeVInt(0)
            if i["OfferID"] in player.PushasedOffers or checkAvailability() == True:
            	self.writeBoolean(True) # Claim
            else:
            	self.writeBoolean(i['Claim']) # Claim
            self.writeVInt(ShopData["Offers"].index(i)) # Offer Index
            self.writeVInt(0)
            self.writeBoolean(i["DailyOffer"])
            self.writeVInt(i["OldPrice"])
            if i["Text"] == "None":
                self.writeString()
            else:
                self.writeString(i["Text"])
            if "TID" in i["Text"]:
            	self.writeVInt(1)
            elif i["Text"] == "None":
            	self.writeVInt(2)
            else:
            	self.writeVInt(0)
            self.writeBoolean(False)
            if i["Background"] == "None":
                self.writeString()
            else:
                self.writeString(i["Background"])
            self.writeVInt(-1)
            self.writeBoolean(i["Processed"])
            self.writeVInt(i["TypeBenefit"])
            self.writeVInt(i["Benefit"])
            self.writeString()
            self.writeBoolean(i["OneTimeOffer"])
            self.writeBoolean(False) # Unk
            if i["BigOffer"] == True:
            	if i["ShopPanelLayouts"] != -1:
            		self.writeDataReference(83, i["ShopPanelLayouts"]) # For Big Offers
            	else:
            		self.writeDataReference(0, 0) # For Big Offers
            	if i["ShopStyleSets"] != -1:
            		self.writeDataReference(70, i["ShopStyleSets"]) # For Big Offers
            	else:
            		self.writeDataReference(0, 0) # For Big Offers
            else:
            	self.writeDataReference(0, 0) # For Big Offers
            	self.writeDataReference(0, 0) # For Big Offers            	
            self.writeBoolean(False)
            self.writeBoolean(False)
            self.writeVInt(0)
            self.writeVInt(-1)
            self.writeVInt(0)
            self.writeBoolean(False)
            self.writeBoolean(False)
            self.writeVInt(0)
            self.writeVInt(0)
            self.writeBoolean(False)
            self.writeVInt(0)
            self.writeBoolean(True)
            self.writeVInt(0)
            self.writeVInt(0)
            self.writeVInt(0)

        
        
        
        self.writeVInt(player.Tokens) #Tokens
        self.writeVInt(1428)

        self.writeVInt(0)

        self.writeVInt(1)
        self.writeVInt(30)

        self.writeByte(1) # count brawlers selected
        self.writeDataReference(16, player.SelectedBrawlers[0]) # selected brawler
        self.writeString(player.Region) # location
        self.writeString(player.ContentCreator) # supported creator

        self.writeVInt(23) # count
        
        #первое значение это кол-во, а второе айди
        
        self.writeVLong(1, 2)  # Unknown
        self.writeVLong(0, 3)  # Tokens Gained
        self.writeVLong(player.TrophiesGained, 4)  # Trophies Gained
        player.TrophiesGained = 0
        self.writeVLong(0, 6)  # Demo Account
        self.writeVLong(player.Invitesblckd, 7)  # Invites Blocked
        self.writeVLong(0, 8)  # Star Points Gained
        self.writeVLong(1, 9)  # Show Star Points
        self.writeVLong(0, 10)  # Power Play Trophies Gained
        self.writeVLong(1, 12)  # Unknown
        self.writeVLong(player.CoinsGained, 14)  # Coins Gained
        player.CoinsGained = 0
        self.writeVLong(player.Agescr, 15)  # AgeScreen | 3 = underage (disable social media) | 1 = age popup
        self.writeVLong(1, 16)
        self.writeVLong(player.Teamchatmuted, 17)  # Team Chat Muted
        self.writeVLong(0, 18)  # Esport Button
        self.writeVLong(0, 19)  # Champion Ship Lives Buy Popup
        self.writeVLong(player.GemsGained, 20)  # Gems Gaine
        player.GemsGained = 0
        self.writeVLong(0, 21)  # Looking For Team State
        self.writeVLong(1, 22)
        self.writeVLong(0, 23)  # Club Trophies Gained
        self.writeVLong(1, 24)  # Have already watched club league stupid animation
        self.writeVLong(32447, 28)  # делит
        self.writeVLong(player.BlingsGained, 32)  # Bling Gained
        self.writeVLong(1488, 37)  # Seria ppdeb


        
        
        self.writeVInt(0)

        self.writeVInt(1)
        for season in range(1):
            self.writeVInt(player.BrawlPassSeason-1)
            self.writeVInt(player.BrawlPassTokens)
            self.writeBoolean(player.BrawlPass) #If true - Brawl Pass on
            self.writeVInt(0)
            self.writeBoolean(False)
            self.writeBoolean(True) #Brawl Pass Collect Rewards
            self.writeInt(player.BrawlPassLVL32)
            self.writeInt(player.BrawlPassLVL64)
            self.writeInt(player.BrawlPassLVL96)
            self.writeInt(1)
            self.writeBoolean(True) #Free Brawl Pass
            self.writeInt(player.BrawlPass1LVL32)
            self.writeInt(player.BrawlPass1LVL64)
            self.writeInt(player.BrawlPass1LVL96)
            self.writeInt(1)
            self.writeBoolean(player.BrawlPassPlus) #If true - Brawl Pass Plus On
            self.writeBoolean(True) #Brawl Pass Plus
            self.writeInt(player.BrawlPassPlusLVL32)
            self.writeInt(player.BrawlPassPlusLVL64)
            self.writeInt(player.BrawlPassPlusLVL96)
            self.writeInt(1)

        self.writeVInt(0)

        self.writeBoolean(True)
        self.writeVInt(0) #count quests
        



        
           
        self.writeVInt(1)
        self.writeVInt(2)
        self.writeVInt(0) 

        self.writeBoolean(True) # Vanity items
        self.writeVInt(len(player.OwnedThumbnails)+len(player.OwnedPins)+len(player.OwnedTitles)+len(player.OwnedSprays))
        for x in player.OwnedThumbnails:
            self.writeVInt(28)
            self.writeVInt(x)
            self.writeVInt(0)
        for x in player.OwnedPins:
            self.writeVInt(52)
            self.writeVInt(x)
            self.writeVInt(0)
        for x in player.OwnedSprays:
            self.writeVInt(68)
            self.writeVInt(x)
            self.writeVInt(0)
        for x in player.OwnedTitles:
            self.writeVInt(76)
            self.writeVInt(x)
            self.writeVInt(0)


        self.writeBoolean(True) # Power league season data
        
        # Power League Data Array Start #
        self.writeVInt(8) # Season
        self.writeVInt(1) # Rank Solo League
        self.writeVInt(8) # Season
        self.writeVInt(1) # Rank Team League
        self.writeVInt(2) # Unk
        self.writeVInt(1) # High Rank Solo League
        self.writeVInt(2) # Unk
        self.writeVInt(1) # High Rank Team League
        self.writeVInt(2) # Unk
        self.writeBoolean(True) # Eligibility for an award
        self.writeVInt(1)
        self.writeVInt(1) # League PlayerData
        self.writeVInt(1)
        self.writeVInt(1)
        self.writeVInt(1)
        
        # Power League Data Array End #

        self.writeInt(0)
        self.writeVInt(12)
        self.writeVInt(16)
        self.writeVInt(player.ProfileBrawler) # Fav Brawler ID
        self.writeBoolean(False)
        self.writeVInt(1)
        self.writeVInt(3)

        self.writeVInt(2023189)

        self.writeVInt(36) # event slot id
        self.writeVInt(1)
        self.writeVInt(2)
        self.writeVInt(3)
        self.writeVInt(4)
        self.writeVInt(5)
        self.writeVInt(6)
        self.writeVInt(7)
        self.writeVInt(8)
        self.writeVInt(9)
        self.writeVInt(10)
        self.writeVInt(11)
        self.writeVInt(12)
        self.writeVInt(13) 
        self.writeVInt(14)
        self.writeVInt(15)
        self.writeVInt(16)
        self.writeVInt(17)
        self.writeVInt(18) 
        self.writeVInt(19)
        self.writeVInt(20)
        self.writeVInt(21) 
        self.writeVInt(22)
        self.writeVInt(23)
        self.writeVInt(24)
        self.writeVInt(25)
        self.writeVInt(26)
        self.writeVInt(27)
        self.writeVInt(28)
        self.writeVInt(29)
        self.writeVInt(30)
        self.writeVInt(31)
        self.writeVInt(32)
        self.writeVInt(33)
        self.writeVInt(34) #гиперзаряд событие
        self.writeVInt(35) #мега копилка
        self.writeVInt(37)

        
        
        GemGrabMap = [7, 8, 9, 10, 11, 40, 7, 8, 9, 10, 11, 40, 7, 8, 9, 10, 11, 40]
        BountyMap = [82, 83, 159, 265, 4, 5, 82, 83, 159, 265, 4, 5, 82, 83, 159, 265, 4, 5]
        BrawlballMap = [24, 26, 50, 51, 24, 26, 50, 51, 24, 26, 50, 51, 24, 26, 50, 51]
        EventIndex = 1

        EventsData = []
        EventsData.append(GemGrabMap[player.EventData])
        EventsData.append(BountyMap[player.EventData])
        EventsData.append(BrawlballMap[player.EventData])
        
        self.writeVInt(len(EventsData) + 8) # Events Count(7 it a ChampionShip(3 Stages) and ClubLeague(PowerMatch and Default Game Mode)) and PowerLeague(Solo and Team Mode)
        for i in EventsData:
              # Default Slots Start Array #
              self.writeVInt(4)
              self.writeVInt(EventIndex)  # EventType
              EventIndex += 1
              self.writeVInt(0)  # EventsBeginCountdown
              self.writeVInt(0)
              self.writeVInt(Utility.timerMath(self, [1970, 1, 13, 0, 0, 0], "dailyoffer"))  # Timer
              self.writeVInt(0)  # tokens reward for new event
              self.writeDataReference(15, i)  # MapID
              self.writeVInt(-64)  # GameModeVariation
              self.writeVInt(0)  # Status
              self.writeString()
              self.writeVInt(0)
              self.writeVInt(0)
              self.writeVInt(0)
              self.writeVInt(0)
              self.writeVInt(0)
              self.writeVInt(0)
              self.writeBoolean(False)  # Map Maker Map Structure Array
              self.writeVInt(0)
              self.writeBoolean(False)  # Power League Data Array
              self.writeVInt(0)
              self.writeVInt(0)
              self.writeBoolean(False)  # ChronosTextEntry
              self.writeBoolean(False)
              self.writeBoolean(False)
              self.writeVInt(-1)
              self.writeBoolean(False)
              self.writeBoolean(False)
              self.writeVInt(-1)
              self.writeVInt(0)
              self.writeVInt(0)
              self.writeVInt(0)
              self.writeBoolean(False)
              # Default Slots End Array #
        
        
        
        self.writeVInt(4)
        self.writeVInt(3) #eventid
        self.writeVInt(1)
        self.writeVInt(0)
        self.writeVInt(72292)
        self.writeVInt(10) 
        self.writeDataReference(15, 10) # map id
        self.writeVInt(-1)
        self.writeVInt(2) #state
        self.writeString("")
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False) # MapMaker map structure array
        self.writeVInt(0)
        self.writeBoolean(False) # Power League array entry
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False)
        self.writeBoolean(False)
        self.writeBoolean(False)
        self.writeVInt(-1)
        self.writeBoolean(False)
        self.writeBoolean(False)
        self.writeVInt(-1)
        self.writeVInt(0) 
        self.writeVInt(0) 
        self.writeVInt(0) 
        self.writeBoolean(False) 
        
        self.writeVInt(4)
        self.writeVInt(2) #eventid
        self.writeVInt(1)
        self.writeVInt(0)
        self.writeVInt(72292)
        self.writeVInt(10) 
        self.writeDataReference(15, 59) # map id
        self.writeVInt(-1)
        self.writeVInt(2) #state
        self.writeString("")
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False) # MapMaker map structure array
        self.writeVInt(0)
        self.writeBoolean(False) # Power League array entry
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False)
        self.writeBoolean(False)
        self.writeBoolean(False)
        self.writeVInt(-1)
        self.writeBoolean(False)
        self.writeBoolean(False)
        self.writeVInt(-1)
        self.writeVInt(0) 
        self.writeVInt(0) 
        self.writeVInt(0) 
        self.writeBoolean(False) 
        
        self.writeVInt(4)
        self.writeVInt(34) #eventid
        self.writeVInt(1)
        self.writeVInt(0)
        self.writeVInt(72292)
        self.writeVInt(10) 
        self.writeDataReference(15, HyperPowerMap) # map id
        self.writeVInt(-1)
        self.writeVInt(2) #state
        self.writeString("")
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False) # MapMaker map structure array
        self.writeVInt(0)
        self.writeBoolean(False) # Power League array entry
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False)
        self.writeBoolean(False)
        self.writeBoolean(False)
        self.writeVInt(-1)
        self.writeBoolean(False)
        self.writeBoolean(False)
        self.writeVInt(-1)
        self.writeVInt(2) 
        self.writeDataReference(15, 24) # map id
        self.writeDataReference(15, 430) # map id
        self.writeVInt(0) 
        self.writeVInt(0) 
        self.writeBoolean(False) 
        
        self.writeVInt(4)
        self.writeVInt(35) #eventid
        self.writeVInt(999999)
        self.writeVInt(999999)
        self.writeVInt(72292)
        self.writeVInt(10) 
        self.writeDataReference(15, 12) # map id
        self.writeVInt(-1)
        self.writeVInt(2) #state
        self.writeString("")
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False) # MapMaker map structure array
        self.writeVInt(0)
        self.writeBoolean(False) # Power League array entry
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False)
        self.writeBoolean(False)
        self.writeBoolean(False)
        self.writeVInt(-1)
        self.writeBoolean(False)
        self.writeBoolean(False)
        self.writeVInt(-1)
        self.writeVInt(0) 
        self.writeVInt(0) 
        self.writeVInt(0) 
        self.writeBoolean(True)
        self.writeVInt(5)
        self.writeVInt(5)
        self.writeVInt(1)
        self.writeVInt(15) # starr drop rewards

        self.writeVInt(4)
        self.writeVInt(1) #eventid
        self.writeVInt(1)
        self.writeVInt(0)
        self.writeVInt(72292)
        self.writeVInt(10) 
        self.writeDataReference(15, 12) # map id
        self.writeVInt(-1)
        self.writeVInt(2) #state
        self.writeString("")
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False) # MapMaker map structure array
        self.writeVInt(0)
        self.writeBoolean(False) # Power League array entry
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False)
        self.writeBoolean(False)
        self.writeBoolean(False)
        self.writeVInt(-1)
        self.writeBoolean(False)
        self.writeBoolean(False)
        self.writeVInt(-1)
        self.writeVInt(0) 
        self.writeVInt(0) 
        self.writeVInt(0) 
        self.writeBoolean(False) 
        
        self.writeVInt(0)
        self.writeVInt(33) #eventid
        self.writeVInt(1)
        self.writeVInt(0)
        self.writeVInt(72292)
        self.writeVInt(10) 
        self.writeDataReference(15, fivevsfivemap) # map id
        self.writeVInt(-1)
        self.writeVInt(2) #state
        self.writeString("")
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False) # MapMaker map structure array
        self.writeVInt(0)
        self.writeBoolean(False) # Power League array entry
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False)
        self.writeBoolean(False)
        self.writeBoolean(False)
        self.writeVInt(-1)
        self.writeBoolean(False)
        self.writeBoolean(False)
        self.writeVInt(-1)
        self.writeVInt(0) 
        self.writeVInt(0) 
        self.writeVInt(0) 
        self.writeBoolean(False) 
        
        self.writeVInt(0)
        self.writeVInt(33) #eventid
        self.writeVInt(1)
        self.writeVInt(0)
        self.writeVInt(72292)
        self.writeVInt(10) 
        self.writeDataReference(15, 382) # map id
        self.writeVInt(-1)
        self.writeVInt(2) #state
        self.writeString("")
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False) # MapMaker map structure array
        self.writeVInt(0)
        self.writeBoolean(False) # Power League array entry
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False)
        self.writeBoolean(False)
        self.writeBoolean(False)
        self.writeVInt(-1)
        self.writeBoolean(False)
        self.writeBoolean(False)
        self.writeVInt(-1)
        self.writeVInt(0) 
        self.writeVInt(0) 
        self.writeVInt(0) 
        self.writeBoolean(False) 
        
        self.writeVInt(-1)
        self.writeVInt(14) #eventid
        self.writeVInt(1)
        self.writeVInt(0)
        self.writeVInt(72292)
        self.writeVInt(10) 
        self.writeDataReference(0,0) # map id
        self.writeVInt(-1)
        self.writeVInt(2) #state
        self.writeString("")
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False) # MapMaker map structure array
        self.writeVInt(0)
        self.writeBoolean(True) # Power League array entry
        # Power League Data Array Start #
        self.writeVInt(9) # Season
        self.writeString("CAT BRAWL!") # Name Season
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(3) # Quests Count
        
        self.writeByte(3) # LogicRewardConfig
        self.writeByte(4) # Quest Type
        self.writeVInt(30) # Rank
        self.writeVInt(1) # Item Array
        self.writeVInt(25) # ItemType
        self.writeVInt(1) 
        self.writeVInt(0)
        self.writeVInt(175) # Thumbnail ID
        
        self.writeByte(3) # LogicRewardConfig
        self.writeByte(2) # Quest Type
        self.writeVInt(7) # Rank
        self.writeVInt(1) # Item Array
        self.writeVInt(25) # ItemType
        self.writeVInt(1) 
        self.writeVInt(0)
        self.writeVInt(174) # Thumbnail ID
        
        self.writeByte(3) # LogicRewardConfig
        self.writeByte(4) # Quest Type
        self.writeVInt(60) # Wins need
        self.writeVInt(1) # Item Array
        self.writeVInt(16) # ItemType
        self.writeVInt(360) 
        self.writeVInt(0)
        self.writeVInt(0) # SkinID
        
        
        self.writeVInt(0) # Quests Count
      
        
        
        
        self.writeVInt(19)# Road Count
        
        self.writeVInt(1) # Rank
        self.writeVInt(500) # Blings
        self.writeVInt(2) # Rank
        self.writeVInt(500) # Blings
        self.writeVInt(3)  # Rank
        self.writeVInt(500) # Blings
        self.writeVInt(4)  # Rank
        self.writeVInt(500) # Blings
        self.writeVInt(5)  # Rank
        self.writeVInt(500) # Blings
        self.writeVInt(6)  # Rank
        self.writeVInt(500) # Blings
        self.writeVInt(7)  # Rank
        self.writeVInt(500) # Blings
        self.writeVInt(8)  # Rank
        self.writeVInt(500) # Blings
        self.writeVInt(9)  # Rank
        self.writeVInt(500) # Blings
        self.writeVInt(10)  # Rank
        self.writeVInt(500) # Blings
        self.writeVInt(11)  # Rank
        self.writeVInt(500) # Blings
        self.writeVInt(12)  # Rank
        self.writeVInt(500) # Blings
        self.writeVInt(13)  # Rank
        self.writeVInt(500) # Blings
        self.writeVInt(14)  # Rank
        self.writeVInt(500) # Blings
        self.writeVInt(15)  # Rank
        self.writeVInt(500) # Blings
        self.writeVInt(16)  # Rank
        self.writeVInt(500) # Blings
        self.writeVInt(17)  # Rank
        self.writeVInt(500) # Blings
        self.writeVInt(18)  # Rank
        self.writeVInt(500) # Blings
        self.writeVInt(19)  # Rank
        self.writeVInt(500) # Blings
       
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False)
        self.writeBoolean(False)
        self.writeBoolean(False)
        self.writeVInt(-1)
        self.writeBoolean(False)
        self.writeBoolean(False)
        self.writeVInt(-1)
        self.writeVInt(0) 
        self.writeVInt(0) 
        self.writeVInt(0) 
        self.writeBoolean(False) 
        
        self.writeVInt(-1)
        self.writeVInt(15) #eventid
        self.writeVInt(1)
        self.writeVInt(0)
        self.writeVInt(72292)
        self.writeVInt(10) 
        self.writeDataReference(0,0) # map id
        self.writeVInt(-1)
        self.writeVInt(2) #state
        self.writeString("")
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False) # MapMaker map structure array
        self.writeVInt(0)
        self.writeBoolean(True) # Power League array entry
        # Power League Data Array Start #
        self.writeVInt(9) # Season
        self.writeString("CAT BRAWL!") # Name Season
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(3) # Quests Count
        
        self.writeByte(3) # LogicRewardConfig
        self.writeByte(4) # Quest Type
        self.writeVInt(30) # Rank
        self.writeVInt(1) # Item Array
        self.writeVInt(25) # ItemType
        self.writeVInt(1) 
        self.writeVInt(0)
        self.writeVInt(106) # Thumbnail ID
        
        self.writeByte(3) # LogicRewardConfig
        self.writeByte(2) # Quest Type
        self.writeVInt(7) # Rank
        self.writeVInt(1) # Item Array
        self.writeVInt(25) # ItemType
        self.writeVInt(1) 
        self.writeVInt(0)
        self.writeVInt(107) # Thumbnail ID
        
        self.writeByte(3) # LogicRewardConfig
        self.writeByte(4) # Quest Type
        self.writeVInt(60) # Wins need
        self.writeVInt(1) # Item Array
        self.writeVInt(16) # ItemType
        self.writeVInt(360) 
        self.writeVInt(0)
        self.writeVInt(775) # SkinID
        
        self.writeVInt(0) # Quests Count
        
        
        
        
        self.writeVInt(19)# Road Count
        
        self.writeVInt(1) # Rank
        self.writeVInt(500) # Blings
        self.writeVInt(2) # Rank
        self.writeVInt(500) # Blings
        self.writeVInt(3)  # Rank
        self.writeVInt(500) # Blings
        self.writeVInt(4)  # Rank
        self.writeVInt(500) # Blings
        self.writeVInt(5)  # Rank
        self.writeVInt(500) # Blings
        self.writeVInt(6)  # Rank
        self.writeVInt(500) # Blings
        self.writeVInt(7)  # Rank
        self.writeVInt(500) # Blings
        self.writeVInt(8)  # Rank
        self.writeVInt(500) # Blings
        self.writeVInt(9)  # Rank
        self.writeVInt(500) # Blings
        self.writeVInt(10)  # Rank
        self.writeVInt(500) # Blings
        self.writeVInt(11)  # Rank
        self.writeVInt(500) # Blings
        self.writeVInt(12)  # Rank
        self.writeVInt(500) # Blings
        self.writeVInt(13)  # Rank
        self.writeVInt(500) # Blings
        self.writeVInt(14)  # Rank
        self.writeVInt(500) # Blings
        self.writeVInt(15)  # Rank
        self.writeVInt(500) # Blings
        self.writeVInt(16)  # Rank
        self.writeVInt(500) # Blings
        self.writeVInt(17)  # Rank
        self.writeVInt(500) # Blings
        self.writeVInt(18)  # Rank
        self.writeVInt(500) # Blings
        self.writeVInt(19)  # Rank
        self.writeVInt(500) # Blings
        
        
        # Power League Data Array End #
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False)
        self.writeBoolean(False)
        self.writeBoolean(False)
        self.writeVInt(-1)
        self.writeBoolean(False)
        self.writeBoolean(False)
        self.writeVInt(-1)
        self.writeVInt(0) 
        self.writeVInt(0) 
        self.writeVInt(0) 
        self.writeBoolean(False) 

        self.writeVInt(0)
       
        ByteStreamHelper.encodeIntList(self, [20, 35, 75, 140, 290, 480, 800, 1250, 1875, 2800])
        ByteStreamHelper.encodeIntList(self, [30, 80, 170, 360]) # Shop Coins Price
        ByteStreamHelper.encodeIntList(self, [300, 880, 2040, 4680]) # Shop Coins Amount

        self.writeVInt(0)

        self.writeVInt(3) # IntValueEntr
        self.writeVLong(41000000 + player.ThemeID, 1)
        self.writeVLong(0, 112) #мастерство без границ
        self.writeVLong(1, 110)

        self.writeVInt(0)
        
        self.writeVInt(0)
        
        self.writeVInt(0)
        self.writeVInt(0)
        
        
        self.writeVInt(2)        
        self.writeVInt(1)
        self.writeVInt(2)
        self.writeVInt(2)
        self.writeVInt(1)
        self.writeVInt(0)
        self.writeVInt(2)
        self.writeVInt(1)
        self.writeVInt(4)

        ByteStreamHelper.encodeIntList(self, [0, 29, 79, 169, 349, 699])
        ByteStreamHelper.encodeIntList(self, [0, 160, 450, 500, 1250, 2500])

        self.writeLong(player.ID[0], player.ID[1])


        self.writeVInt(5) # Notification factory
        
        self.writeVInt(81)
        self.writeInt(228) #Notification ID
        self.writeBoolean(False)
        self.writeInt(0)
        self.writeString("Приветствуем вас во входящих! \n Сообщения ниже нужны для смены сезона Brawl Pass и фонов в меню!")
        self.writeVInt(1)
        self.writeVInt(1)
        
        self.writeVInt(81)
        self.writeInt(229) #Notification ID
        self.writeBoolean(False)
        self.writeInt(0)
        self.writeString("Сохраните данные своей учетной записи! Например, сделайте скриншот\n"f"Ваше Имя: " + str(player.Name) + "\n"f"Ваш Account ID: " + str(player.ID) + "\n"f"Ваш регион: " + str(player.Region) + "\n"f"Эти данные нужны для переноса учетной записи на новое устройство, а также для приобретения внутриигровой валюты""\n"f"НИКОМУ кроме администрации не предоставляйте эти данные!!!")
        self.writeVInt(1)
        self.writeVInt(1)
        
        self.writeVInt(71)
        self.writeInt(2) #Notification ID
        self.writeBoolean(False)
        self.writeInt(0)
        self.writeString("я плохая 😈 ты хороший 🤓 рот от гнева перекошен 😋 не кричи🥵 я не глухая 😱 ты хороший 🤯 я плохая 🤨")
        self.writeVInt(1)
        if player.BrawlPassSeason == 22:
            self.writeVInt(22)
        else:
            self.writeVInt(21)
        
        if player.BrawlPassSeason == 22:
            self.writeVInt(2)
        else:
            self.writeVInt(1)
            
            
        self.writeVInt(72)
        self.writeInt(1) #Notification ID
        self.writeBoolean(False)
        self.writeInt(0)
        self.writeString("СЛУЧАЙНЫЙ КИТАЙСКИЙ ФОН")
        self.writeVInt(1)
        self.writeVInt(16000000 + 29)
        
        self.writeVInt(83)
        self.writeInt(7) #Notification ID
        self.writeBoolean(False)
        self.writeInt(0)
        self.writeString("")
        self.writeVInt(1)
        
        self.writeString("Подпишись на нас в Telegram!")
        self.writeVInt(1)
        
        self.writeString("Ты знал, что у Cat Brawl есть официальный телеграм-канал, где мы сразу выпускаем посты об обновлениях? А еще там есть веселый чят.")
        self.writeVInt(1)
        
        self.writeString("Посмотреть")
        self.writeVInt(1)
        # Banner Data
        self.writeString("/b2d704b22b95a4d70f66e89da867a64b")
        self.writeString("3a35620676c1d08d12086257a5ae03eb612452d8")
#        # End
        self.writeString("brawlstars://shop")
        self.writeVInt(1)
        self.writeVInt(1)
        
        
        self.writeVInt(1)
        self.writeBoolean(False)
        self.writeVInt(0)
        self.writeVInt(0) 
        self.writeVInt(0)
        self.writeBoolean(True) # Daily Login Calendar
        
        
        
        '''
        Daily Login Calendar IDs:
        3: Brawler Choice
        4: Skin
        5: Gadget / Starpower Choice
        19: Pin
        20: Double Pin
        34: Upgrade to Level
        '''
        
        
        
        self.writeVInt(1)
        self.writeVInt(2) # Amount
        #1
        self.writeVInt(0)
        self.writeVInt(1)
        
        self.writeVInt(4)
        self.writeVInt(1)
        self.writeDataReference(0)
        self.writeVInt(669)
        self.writeBoolean(True)
        self.writeVInt(1)
        
        #2
        self.writeVInt(1)
        self.writeVInt(1) # Count
        
        self.writeVInt(3)
        self.writeVInt(1)
        self.writeDataReference(16,76)
        self.writeVInt(0)
        self.writeBoolean(False)
        #self.writeVInt(1)

        
        
        
        
        self.writeVInt(1) # CycleGiftSlotArray
        # Don't change!
        
        
        '''
        Cycle Tutorial:
        1. Change the Count in Road 1 to amount rewards u want
        2. Add Rewards (ItemGiftSlot and normal reward structure for support)
        3. Do the step 1, 2 in Road 2
        4. Change the ID's in Road 2 if u want rewards to choose.
        '''

       
        #Road
       
        self.writeVInt(1) # ItemCycle
        self.writeVInt(13) # Count
        
        self.writeVInt(2) # Day
        self.writeVInt(1) # Count
       
        self.writeVInt(34) # ItemType
        self.writeVInt(5) # Count
        self.writeDataReference(16, 76) # BrawlerID
        self.writeVInt(0) # CsvID
        self.writeBoolean(False) # Unk
        #self.writeVInt(1)
       
       # ItemGiftSlot       
        self.writeVInt(3) # Day
        self.writeVInt(1) # Count
       
        self.writeVInt(19) # ItemType
        self.writeVInt(1) # Count
        self.writeDataReference(16, 76) # BrawlerID
        self.writeVInt(1381) # CsvID
        self.writeBoolean(True) # Unk
        self.writeVInt(1)
       
        self.writeVInt(4) # Day
        self.writeVInt(1) # Count
       
        self.writeVInt(34) # ItemType
        self.writeVInt(7) # Count
        self.writeDataReference(16, 76) # BrawlerID
        self.writeVInt(0) # CsvID
        self.writeBoolean(True) # Unk
        self.writeVInt(1)
        
        self.writeVInt(5) # Day
        self.writeVInt(1) # Count
       
        self.writeVInt(4) # ItemType
        self.writeVInt(7) # Count
        self.writeDataReference(16, 76) # BrawlerID
        self.writeVInt(532) # CsvID
        self.writeBoolean(False) # Unk
        #self.writeVInt(1)
        
        self.writeVInt(6) # Day
        self.writeVInt(1) # Count
       
        self.writeVInt(34) # ItemType
        self.writeVInt(8) # Count
        self.writeDataReference(16, 76) # BrawlerID
        self.writeVInt(267) # CsvID
        self.writeBoolean(False) # Unk
        #self.writeVInt(1)

        
        self.writeVInt(7) # Day
        self.writeVInt(1) # Count
       
        self.writeVInt(19) # ItemType
        self.writeVInt(1) # Count
        self.writeDataReference(16, 76) # BrawlerID
        self.writeVInt(931) # CsvID
        self.writeBoolean(False) # Unk
       #self.writeVInt(1)
       
        self.writeVInt(8) # Day
        self.writeVInt(1) # Count
       
        self.writeVInt(34) # ItemType
        self.writeVInt(9) # Count
        self.writeDataReference(16, 76) # BrawlerID
        self.writeVInt(127) # CsvID
        self.writeBoolean(False) # Unk
       #self.writeVInt(1)
       
        self.writeVInt(9) # Day
        self.writeVInt(1) # Count
       
        self.writeVInt(19) # ItemType
        self.writeVInt(1) # Count
        self.writeDataReference(16, 76) # BrawlerID
        self.writeVInt(932) # CsvID
        self.writeBoolean(False) # Unk
       #self.writeVInt(1)
       
        self.writeVInt(10) # Day
        self.writeVInt(1) # Count
       
        self.writeVInt(34) # ItemType
        self.writeVInt(10) # Count
        self.writeDataReference(16, 76) # BrawlerID
        self.writeVInt(127) # CsvID
        self.writeBoolean(False) # Unk
       #self.writeVInt(1)
       
        # here be very important.......
       
        self.writeVInt(11) # Day
        self.writeVInt(1) # Count
       
        self.writeVInt(19) # ItemType
        self.writeVInt(1) # Count
        self.writeDataReference(16, 76) # BrawlerID
        self.writeVInt(947) # CsvID
        self.writeBoolean(False) # Unk
        #self.writeVInt(1)
                
        self.writeVInt(12) # Day
        self.writeVInt(1) # Count
       
        self.writeVInt(34) # ItemType
        self.writeVInt(11) # Count
        self.writeDataReference(16, 76) # BrawlerID
        self.writeVInt(89) # CsvID
        self.writeBoolean(False) # Unk
        #self.writeVInt(1)
        

        
        self.writeVInt(13) # Day
        self.writeVInt(1) # Count
       
        self.writeVInt(19) # ItemType
        self.writeVInt(1) # Count
        self.writeDataReference(16, 76) # BrawlerID
        self.writeVInt(948) # CsvID
        self.writeBoolean(False) # Unk
        #self.writeVInt(1)
                
        self.writeVInt(14)
        self.writeVInt(2) # Count
        
        self.writeVInt(3)
        self.writeVInt(1)
        self.writeDataReference(16, 43)
        self.writeVInt(0)
        self.writeBoolean(False)
        #self.writeVInt(1)
        
        self.writeVInt(3)
        self.writeVInt(1)
        self.writeDataReference(16, 50)
        self.writeVInt(0)
        self.writeBoolean(False)
        #self.writeVInt(1)
        jaj = 0
        
        self.writeVInt(0) # DayArrayRange
        self.writeVInt(0) # Timer
        self.writeVInt(99999)
        self.writeVInt(0)
        self.writeVInt(0) # Road (if Poco Road - 1, if Brock Road - 2)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        
        self.writeVInt(0)
        self.writeBoolean(False) # Starr Road
        
        

        self.writeVInt(ownedBrawlersCount) #mastr

        for brawlerID, brawlerInfo in player.OwnedBrawlers.items():
            self.writeVInt(brawlerInfo["Mastery"])
            self.writeVInt(brawlerInfo["ClaimRewardsMastery"])
            self.writeDataReference(16, brawlerID)
        

        
        self.writeVInt(0)
        # Battle Map
        self.writeDataReference(28, player.BattleIcon1) # Icon 1
        self.writeDataReference(28, player.BattleIcon2) # Icon 2
        self.writeDataReference(52, player.BattlePin) # Pin
        self.writeDataReference(76, player.Title) # Title
        self.writeBoolean(False)
        self.writeBoolean(False)
        self.writeBoolean(False)
        self.writeBoolean(False)

        self.writeVInt(0) #Brawler's BattleCards

        starrDropOpening.encode(self)

        self.writeBoolean(False)

        # end LogicClientHome

        self.writeVLong(player.ID[0], player.ID[1])
        self.writeVLong(player.ID[0], player.ID[1])
        self.writeVLong(player.ID[0], player.ID[1])
        self.writeStringReference(player.Name)
        self.writeBoolean(player.Registered)
        self.writeInt(-1)

        self.writeVInt(17)
        unlocked_brawler = [i['CardID'] for x,i in player.OwnedBrawlers.items()]
        self.writeVInt(len(unlocked_brawler) + 5)
        for x in unlocked_brawler:
            self.writeDataReference(23, x)
            self.writeVInt(-1)
            self.writeVInt(1)

        self.writeDataReference(5, 8)
        self.writeVInt(-1)
        self.writeVInt(player.Coins)
        
        self.writeDataReference(5, 18)
        self.writeVInt(-1)
        self.writeVInt(5) # Unlocked Sprays Slots

        self.writeDataReference(5, 23)
        self.writeVInt(-1)
        self.writeVInt(player.Blings)
        
        self.writeDataReference(5, 22)

        self.writeVInt(-1)

        self.writeVInt(player.PowerPoints)
        
        self.writeDataReference(5, 21)

        self.writeVInt(-1)

        self.writeVInt(player.Fame)


        self.writeVInt(len(player.OwnedBrawlers)) # HeroScore
        for x,i in player.OwnedBrawlers.items():
            self.writeDataReference(16, x)
            self.writeVInt(-1)
            self.writeVInt(i["Trophies"])

        self.writeVInt(len(player.OwnedBrawlers)) # HeroHighScore
        for x,i in player.OwnedBrawlers.items():
            self.writeDataReference(16, x)
            self.writeVInt(-1)
            self.writeVInt(i["HighestTrophies"])

        self.writeVInt(0) # Array

        self.writeVInt(0) # HeroPower
        
        self.writeVInt(len(player.OwnedBrawlers)) # HeroLevel
        for x,i in player.OwnedBrawlers.items():
            self.writeDataReference(16, x)
            self.writeVInt(-1)
            self.writeVInt(i["PowerLevel"]-1)

        # Brawlers Star Powers Array Start #
        allStarpowers = player.allStarpowers
        self.writeVInt(len(allStarpowers))  # Count
        if brawlerInfo["PowerLevel"] >= 9:
            for x in allStarpowers:
            	self.writeDataReference(23, x)  # Cards ID
            	self.writeVInt(1)
            	self.writeVInt(1)  # Star Power Unlocked State
        else:
        	for x in allStarpowers:
        	   self.writeDataReference(23, x)  # Cards ID
        	   self.writeVInt(1)
        	   self.writeVInt(0)  # Star Power Unlocked State
        # Brawlers Star Powers Array End #

        self.writeVInt(len(player.OwnedBrawlers)) # HeroSeenState
        for x,i in player.OwnedBrawlers.items():
            self.writeDataReference(16, x)
            self.writeVInt(-1)
            self.writeVInt(2)

        self.writeVInt(0) # Array
        self.writeVInt(0) # Array
        self.writeVInt(0) # Array
        self.writeVInt(0) # Array
        self.writeVInt(0) # Array
        self.writeVInt(0) # Array
        self.writeVInt(0) # Array
        self.writeVInt(0) # Array
        self.writeVInt(0) # Array

        self.writeVInt(player.Gems) # Diamonds
        self.writeVInt(player.Gems) # Free Diamonds
        self.writeVInt(10) # Player Level
        self.writeVInt(100)
        self.writeVInt(0) # CumulativePurchasedDiamonds or Avatar User Level Tier | 10000 < Level Tier = 3 | 1000 < Level Tier = 2 | 0 < Level Tier = 1
        self.writeVInt(100) # Battle Count
        self.writeVInt(10) # WinCount
        self.writeVInt(80) # LoseCount
        self.writeVInt(50) # WinLooseStreak
        self.writeVInt(20) # NpcWinCount
        self.writeVInt(0) # NpcLoseCount
        self.writeVInt(2) # TutorialState | shouldGoToFirstTutorialBattle = State == 0
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeString()
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
       

    def decode(self):
        fields = {}
        return fields

    def execute(message, calling_instance, fields):
        pass

    def getMessageType(self):
        return 24101

    def getMessageVersion(self):
        return self.messageVersion