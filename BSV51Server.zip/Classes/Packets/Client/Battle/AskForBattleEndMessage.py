from Classes.Messaging import Messaging

from Classes.Packets.PiranhaMessage import PiranhaMessage

from Database.DatabaseHandler import DatabaseHandler

import random

from JSON.JSONHandler import JSONHandler

class AskForBattleEndMessage(PiranhaMessage):
    def __init__(self, messageData):
        super().__init__(messageData)
        self.messageVersion = 0

    def encode(self, fields):
        pass

    def decode(self):
        fields = {}
        fields["BattleResult"] = self.readVInt()
        fields["Result"] = self.readVInt()
        fields["Rank"] = self.readVInt()
        fields["MapID"] = self.readDataReference()
        fields["HeroesCount"] = self.readVInt()
        fields["Heroes"] = []
        for i in range(fields["HeroesCount"]): fields["Heroes"].append({"Brawler": {"ID": self.readDataReference(), "SkinID": self.readDataReference()}, "Team": self.readVInt(), "IsPlayer": self.readBoolean(), "PlayerName": self.readString()})
        super().decode(fields)
        return fields

    def execute(message, calling_instance, fields, cryptoInit):
        fields["Socket"] = calling_instance.client
        db_instance = DatabaseHandler()
        
        playerData = db_instance.getPlayer(calling_instance.player.ID)
        
        SelectedBrawler = playerData["SelectedBrawler"]
        
        
        
        def encodeStarrDrop():
        	randomvalue = random.randint(1, 2250)
        	if randomvalue <= 500:
        		a = JSONHandler.RareDropsData
        		fields["Rarity"] = 0
        	elif randomvalue <= 1000:
        		a = JSONHandler.SuperRareDropsData
        		fields["Rarity"] = 1
        	elif randomvalue <= 2000:
        		a = JSONHandler.EpicDropsData
        		fields["Rarity"] = 2
        	elif randomvalue <= 2200:
        		a = JSONHandler.MythicDropsData
        		fields["Rarity"] = 3
        	else:
        		a = JSONHandler.LegendaryDropsData
        		fields["Rarity"] = 4	
        	playerData["DropRarity"] = fields["Rarity"]
        	for i in a["DropsData"]:
        		item = random.choice(i["Items"])
        		ItemID = item["ItemID"]       			
        		Fallback = random.randint(item["MinFallback"], item["MaxFallback"])
        		DeliveryID = item["DeliveryID"]
        		DataRef = item["DataRef"]
        		if ItemID == "OwnedPins":
        			RandomItem = random.randint(52, 1000)
        		elif ItemID == "Spyrays":
        			RandomItem = random.randint(17, 191)
        		else:
        			RandomItem = random.randint(12, 100)
        	
        			
        	playerData["GatchaItems"] = {'Boxes': []}
        	box = {'Type': 0, 'Items': []}	
        	item = {'Amount': Fallback, 'DataRef': [DataRef, RandomItem],  'RewardID': DeliveryID}
        	box['Items'].append(item)
        	box['Type'] = 100
        	playerData["GatchaItems"]['Boxes'].append(box)
        	DeprecatedItems = ["OwnedPins", "OwnedThumbnails", "Spyrays"]
        	if ItemID not in DeprecatedItems:
        		SaveList = [] 
        		SaveList.append(Fallback)
        		playerData[ItemID] += SaveList[0]
        		SaveList.clear()
        	else:
        		SaveList = []
        		SaveList.append(RandomItem)
        		playerData[ItemID].append(SaveList[0])
        		SaveList.clear()	
        	playerData["DropAmount"] = 1
        	if True:
        		db_instance.updatePlayerData(playerData, calling_instance)
        		fields["Socket"] = calling_instance.client
        		fields["Command"] = {"ID": 228}
        		fields["PlayerID"] = calling_instance.player.ID
        		fields["StarrDrops"] = True
        		fields["Offer"] = 17299
        		fields["Wins"] = playerData["DailyWins"]
        		Messaging.sendMessage(24111, fields, cryptoInit) 
        		fields["Socket"] = calling_instance.client
        		fields["Command"] = {"ID": 203}
        		fields["StarrDrops"] = True
        		fields["PlayerID"] = calling_instance.player.ID
        		Messaging.sendMessage(24111, fields, cryptoInit)
        		fields["Socket"] = calling_instance.client
        		fields["Command"] = {"ID": 228}
        		fields["PlayerID"] = calling_instance.player.ID
        		fields["StarrDrops"] = False
        		fields["Offer"] = 17399
        		fields["Wins"] = playerData["DailyWins"]
        		Messaging.sendMessage(24111, fields, cryptoInit)
        		
        def giveBattleEndResources(amount0, amount1):
        	playerData["Trophies"] += amount0
        	playerData["Tokens"] += amount1
        	
        def addDailyWin():
        	playerData["DailyWins"] += 1
        	
        def addBrawlerResources():
        	playerData["OwnedBrawlers"][f"{SelectedBrawler}"]["HighestTrophies"] += 8
        	playerData["OwnedBrawlers"][f"{SelectedBrawler}"]["Trophies"] += 8
        	playerData["OwnedBrawlers"][f"{SelectedBrawler}"]["MasteryPoints"] += 100
        	
        	
        	
        def skipDrop():
        	fields["Socket"] = calling_instance.client
        	fields["Command"] = {"ID": 228}
        	fields["PlayerID"] = calling_instance.player.ID
        	fields["StarrDrops"] = False
        	fields["Offer"] = 17399
        	fields["Wins"] = playerData["DailyWins"]
        	Messaging.sendMessage(24111, fields, cryptoInit)
        	
        
        if fields["BattleResult"] == 0 and fields["MapID"][1] != 393:
        	giveBattleEndResources(8, 250)
        	addDailyWin()
        	addBrawlerResources()
        	fields["GameMode"] = 1
        	WinDrops = [1, 4, 8]
        	if playerData["DailyWins"] in WinDrops:
        		encodeStarrDrop()
        	else:
        		skipDrop()        		        		
        	GemDrop = random.randint(0, 5)
        	if GemDrop == 5:
        		playerData["Gems"] += 1
        	
        if fields["BattleResult"] == 1 and fields["MapID"][1] != 393:
        	playerData["Tokens"] += 100
        	fields["GameMode"] = 1
        	if playerData["Trophies"] == 0:
        		pass
        	else:
        		playerData["Trophies"] -= 8
        		playerData["OwnedBrawlers"][f"{SelectedBrawler}"]["Trophies"] -= 8
        
        if fields["BattleResult"] == 10 and fields["MapID"][1] == 393:
        	fields["GameMode"] = 2
        	fields["ShowdownResult"] = 1
        	playerData["Tokens"] += 10
        	if playerData["Trophies"] == 0:
        		pass
        	else:
        		playerData["Trophies"] -= 10
        		playerData["OwnedBrawlers"][f"{SelectedBrawler}"]["Trophies"] -= 10
        
        if fields["BattleResult"] == 9 and fields["MapID"][1] == 393:
        	playerData["Tokens"] += 30
        	fields["GameMode"] = 2
        	fields["ShowdownResult"] = 1
        	if playerData["Trophies"] == 0:
        		pass
        	else:
        		playerData["Trophies"] -= 8
        		playerData["OwnedBrawlers"][f"{SelectedBrawler}"]["Trophies"] -= 8
        		
        if fields["BattleResult"] == 8 and fields["MapID"][1] == 393:
        	playerData["Tokens"] += 50
        	fields["GameMode"] = 2
        	fields["ShowdownResult"] = 1
        	if playerData["Trophies"] == 0:
        		pass
        	else:
        		playerData["Trophies"] -= 6
        		playerData["OwnedBrawlers"][f"{SelectedBrawler}"]["Trophies"] -= 6
        		
        if fields["BattleResult"] == 7 and fields["MapID"][1] == 393:
        	playerData["Tokens"] += 70
        	fields["GameMode"] = 2
        	fields["ShowdownResult"] = 1
        	if playerData["Trophies"] == 0:
        		pass
        	else:
        		playerData["Trophies"] -= 4
        		playerData["OwnedBrawlers"][f"{SelectedBrawler}"]["Trophies"] -= 4
        		
        if fields["BattleResult"] == 6 and fields["MapID"][1] == 393:
        	playerData["Tokens"] += 90
        	fields["GameMode"] = 2
        	fields["ShowdownResult"] = 1
        	if playerData["Trophies"] == 0:
        		pass
        	else:
        		playerData["Trophies"] -= 2
        		playerData["OwnedBrawlers"][f"{SelectedBrawler}"]["Trophies"] -= 2
        		
        if fields["BattleResult"] == 5 and fields["MapID"][1] == 393:
        	addDailyWin()
        	playerData["Tokens"] += 120
        	fields["GameMode"] = 2
        	fields["ShowdownResult"] = 0
        	if playerData["Trophies"] == 0:
        		pass
        	else:
        		playerData["Trophies"] += 2
        		playerData["OwnedBrawlers"][f"{SelectedBrawler}"]["Trophies"] += 2
        		
        if fields["BattleResult"] == 4 and fields["MapID"][1] == 393:
        	addDailyWin()
        	playerData["Tokens"] += 160
        	fields["GameMode"] = 2
        	fields["ShowdownResult"] = 0
        	if playerData["Trophies"] == 0:
        		pass
        	else:
        		playerData["Trophies"] += 4
        		playerData["OwnedBrawlers"][f"{SelectedBrawler}"]["Trophies"] += 4
        		
        if fields["BattleResult"] == 3 and fields["MapID"][1] == 393:
        	addDailyWin()
        	playerData["Tokens"] += 180
        	fields["GameMode"] = 2
        	fields["ShowdownResult"] = 0
        	if playerData["Trophies"] == 0:
        		pass
        	else:
        		playerData["Trophies"] += 6
        		playerData["OwnedBrawlers"][f"{SelectedBrawler}"]["Trophies"] += 6
        		
        if fields["BattleResult"] == 2 and fields["MapID"][1] == 393:
        	addDailyWin()
        	playerData["Tokens"] += 240
        	fields["GameMode"] = 2
        	fields["ShowdownResult"] = 0
        	if playerData["Trophies"] == 0:
        		pass
        	else:
        		playerData["Trophies"] += 8
        		playerData["OwnedBrawlers"][f"{SelectedBrawler}"]["Trophies"] += 8
        
        if fields["BattleResult"] == 1 and fields["MapID"][1] == 393:
        	addDailyWin()
        	playerData["Tokens"] += 350
        	fields["GameMode"] = 2
        	fields["ShowdownResult"] = 0
        	if playerData["Trophies"] == 0:
        		pass
        	else:
        		playerData["Trophies"] += 10
        		playerData["OwnedBrawlers"][f"{SelectedBrawler}"]["Trophies"] += 10
        		
        		
        Messaging.sendMessage(23456, fields, cryptoInit, calling_instance.player)      	       		        	
        db_instance.updatePlayerData(playerData, calling_instance)
        

    def getMessageType(self):
        return 14110

    def getMessageVersion(self):
        return self.messageVersion
