from Classes.Messaging import Messaging

from Classes.Packets.PiranhaMessage import PiranhaMessage
from Classes.BitStream import BitStream

class ClientInputMessage(PiranhaMessage):
    
    def __init__(self, messageData):
        super().__init__(messageData)
        self.messageVersion = 0

    def encode(self, fields):
        pass

    def decode(self):
        stream = BitStream()
        fields = {}
        battleData = []
        stream.readPositiveInt(14)
        stream.readPositiveInt(10)
        stream.readPositiveInt(13)
        stream.readPositiveInt(10)
        stream.readPositiveInt(10)
        Unk1 = stream.readPositiveInt(5)
        for i in range(Unk1):
        	battleData.append(self.getBattleFunctionality())
        
        if battleData != []:
        	ponos = pomet[0]
        	self.player.dudu = ponos["counter"]
        return fields

    def execute(message, calling_instance, fields):
        pass

    def getMessageType(self):
        return 10555

    def getMessageVersion(self):
        return self.messageVersion

    def getBattleFunctionality(self):
    	stream = BitStream()
    	streamFields = {}
    	streamFields["Counter"] = stream.readPositiveInt(15)
    	streamFields["ID"] = stream.readPositiveInt(4)
    	streamFields["BattleX"] = stream.readInt(15)
    	streamFields["BattleY"] = stream.readInt(15)
    	streamFields["AutoAim"] = stream.readBoolean()
    	if streamFields["ID"] == 9:
    		streamFields["EmoteID"] = stream.readPositiveInt(3)
    	if streamFields["AutoAim"]:
    		streamFields["isAimed"] = stream.readBoolean()
    		if isAimed:
    			stream.readPositiveInt(14)
    	return streamFields