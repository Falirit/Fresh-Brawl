class Alliance:
    pass